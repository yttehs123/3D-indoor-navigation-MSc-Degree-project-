﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeLevels : MonoBehaviour
{
    // Start is called before the first frame update

    public Text txt;

    public GameObject floor_zero;
    public GameObject floor_one;
    public GameObject floor_two;
    public GameObject floor_three;
    public void LevelUp()
    {
        var totext = txt.text.ToString();
        var cnt = Int32.Parse(totext);
        if(cnt < 3) { 
            cnt = Int32.Parse(totext) + 1;
        }
        txt.text = cnt.ToString();
        HideShowLevels(cnt);
    }

    // Update is called once per frame
    public void LevelDown()
    {
        var totext = txt.text.ToString();
        var cnt = Int32.Parse(totext);
        if (cnt > 0)
        {
            cnt = Int32.Parse(totext) - 1;
        }
        txt.text = cnt.ToString();
        HideShowLevels(cnt);
    }

    public void HideShowLevels(int floor)
    {
        Debug.Log(floor);
        if(floor == 0)
        {
            // change active floors
            floor_one.SetActive(false);
            floor_two.SetActive(false);
            floor_three.SetActive(false);
        }
        else if (floor == 1)
        {
            // change active floors
            floor_one.SetActive(true);
            floor_two.SetActive(false);
            floor_three.SetActive(false);

            // change active floors
            floor_zero.transform.localScale = new Vector3(15, 15, 15);
            floor_zero.transform.localPosition = new Vector3(-5008, 5248, -2623);
        }
        else if (floor == 2)
        {
            // change active floors
            floor_one.SetActive(true);
            floor_two.SetActive(true);
            floor_three.SetActive(false);

            // change active floors
            floor_one.transform.localScale = new Vector3((float)4.5387, (float)4.5, (float)4.5);
            floor_one.transform.localPosition = new Vector3((float)8990.3, -11934, 12500);
        }
        else if (floor == 3)
        {
            // change active floors
            floor_one.SetActive(true);
            floor_two.SetActive(true);
            floor_three.SetActive(true);

            // change active floors
            floor_two.transform.localScale = new Vector3((float)4.5387, (float)4.5, (float)4.5);
            floor_two.transform.localPosition = new Vector3((float)8990.3, -11768, 12500);
        }
    }
}
