﻿// ===========
// This script moves the camera position based on the user input.
// 29-6-2020
// Rinus Vijftigschild
// ===========

// packages
using UnityEngine;

public class CameraController : MonoBehaviour
{
    // input varaibles
    public float panSpeed = 20f;
    public float panBorderThickness = 10f;
    public Vector2 panLimit;
    public float scrollspeed = 20f;

    // Update is called once per frame
    void Update()
    {
        Vector3 pos = transform.position;
        // move camera up
        if (Input.GetKey("up") || Input.mousePosition.y >= Screen.height - panBorderThickness)
        {
            pos.z += panSpeed * Time.deltaTime;
        }
        // move camera down
        if (Input.GetKey("down") || Input.mousePosition.y <= panBorderThickness)
        {
            pos.z -= panSpeed * Time.deltaTime;
        }
        // move camera right
        if (Input.GetKey("right") || Input.mousePosition.x >= Screen.height - panBorderThickness)
        {
            pos.x += panSpeed * Time.deltaTime;
        }
        // move camera left
        if (Input.GetKey("left") || Input.mousePosition.x <= panBorderThickness)
        {
            pos.x -= panSpeed * Time.deltaTime;
        }

        // zoom in and out
        float scroll = Input.GetAxis("Mouse ScrollWheel");

        // update camera position
        pos.y -= scroll * scrollspeed * 100f * Time.deltaTime;
        pos.x = Mathf.Clamp(pos.x, -panLimit.x, panLimit.x);
        pos.y = Mathf.Clamp(pos.y, -panLimit.y, panLimit.y);
        transform.position = pos;
    }
}
