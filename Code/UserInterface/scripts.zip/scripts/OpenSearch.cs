﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class OpenSearch : MonoBehaviour
{
    public GameObject Panel;

    public GameObject SearchButton;

    public GameObject HideSearch;
    // Start is called before the first frame update
    public void OpenPanel()
    {
        if(Panel != null)
        {
           Panel.SetActive(true);
           SearchButton.SetActive(false);
            HideSearch.SetActive(true);
        }
    }


    public void ClosePanel()
    {
        if (Panel != null)
        {
            Panel.SetActive(false);
            SearchButton.SetActive(true);
            HideSearch.SetActive(false);
        }
    }
}
