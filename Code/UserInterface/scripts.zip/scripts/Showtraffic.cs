﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mapbox.Unity.Map;

public class Showtraffic : MonoBehaviour
{
    public GameObject _maplayers;

    bool isvisable = false;

    public void HideTraffic()
    {
        _maplayers.GetComponent<AbstractMap>().VectorData.FindFeatureSubLayerWithName("LowTraffic").SetActive(isvisable);
        _maplayers.GetComponent<AbstractMap>().VectorData.FindFeatureSubLayerWithName("ModerateTraffic").SetActive(isvisable);
        _maplayers.GetComponent<AbstractMap>().VectorData.FindFeatureSubLayerWithName("HeavyTraffic").SetActive(isvisable);
        _maplayers.GetComponent<AbstractMap>().VectorData.FindFeatureSubLayerWithName("SevereTraffic").SetActive(isvisable);
        if (isvisable)
        {
            isvisable = false;
        }
        else
        {
            isvisable = true;
        }
    }


    bool buildingvisable = false;

    public void HideBuildings()
    {
        _maplayers.GetComponent<AbstractMap>().VectorData.FindFeatureSubLayerWithName("Buildings").SetActive(buildingvisable);
        if (buildingvisable)
        {
            buildingvisable = false;
        }
        else
        {
            buildingvisable = true;
        }
    }


    bool firestations = false;

    public void HideStations()
    {
        _maplayers.GetComponent<AbstractMap>().VectorData.FindPointsofInterestSubLayerWithName("Firestations").SetActive(firestations);
        if (firestations)
        {
            firestations = false;
        }
        else
        {
            firestations = true;
        }
    }
}
