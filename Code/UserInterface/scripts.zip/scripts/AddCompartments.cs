﻿// ===========
// This script changes the materials of the model
// 29-6-2020
// Rinus Vijftigschild
// ===========

// packages
using UnityEngine;

public class AddCompartments : MonoBehaviour
{
    public Material[] material;
    Renderer rend;

    public GameObject floor;

    // Start is called before the first frame update
    void Start()
    {
        rend = GetComponent<Renderer>();
        rend.enabled = true;
    }

    bool active = true;

    // Add/Remove compartments from model
    public void AddComp()
    {
        // Get the different floors 
        var floor0 = floor.transform.GetChild(0);
        var floor1 = floor.transform.GetChild(1);
        var floor2 = floor.transform.GetChild(2);
        var floor3 = floor.transform.GetChild(3);

        if (active) {
      
            // comp1
            var comp1_3_1 = floor3.GetChild(5).GetChild(0).GetComponent<Renderer>();
            comp1_3_1.enabled = true;
            comp1_3_1.sharedMaterial = material[1];

            var comp1_3_2 = floor3.GetChild(6).GetChild(0).GetComponent<Renderer>();
            comp1_3_2.enabled = true;
            comp1_3_2.sharedMaterial = material[1];

            var comp1_2_1 = floor2.GetChild(14).GetChild(0).GetComponent<Renderer>();
            comp1_2_1.enabled = true;
            comp1_2_1.sharedMaterial = material[1];

            var comp1_2_2 = floor2.GetChild(13).GetChild(0).GetComponent<Renderer>();
            comp1_2_2.enabled = true;
            comp1_2_2.sharedMaterial = material[1];

            var comp1_2_3 = floor2.GetChild(11).GetChild(0).GetComponent<Renderer>();
            comp1_2_3.enabled = true;
            comp1_2_3.sharedMaterial = material[1];

            var comp1_1_1 = floor1.GetChild(14).GetChild(0).GetComponent<Renderer>();
            comp1_1_1.enabled = true;
            comp1_1_1.sharedMaterial = material[1];

            var comp1_1_2 = floor1.GetChild(13).GetChild(0).GetComponent<Renderer>();
            comp1_1_2.enabled = true;
            comp1_1_2.sharedMaterial = material[1];

            var comp1_1_3 = floor1.GetChild(11).GetChild(0).GetComponent<Renderer>();
            comp1_1_3.enabled = true;
            comp1_1_3.sharedMaterial = material[1];

            var comp1_0_1 = floor0.GetChild(14).GetChild(0).GetComponent<Renderer>();
            comp1_0_1.enabled = true;
            comp1_0_1.sharedMaterial = material[1];

            var comp1_0_2 = floor0.GetChild(13).GetChild(0).GetComponent<Renderer>();
            comp1_0_2.enabled = true;
            comp1_0_2.sharedMaterial = material[1];

            var comp1_0_3 = floor0.GetChild(11).GetChild(0).GetComponent<Renderer>();
            comp1_0_3.enabled = true;
            comp1_0_3.sharedMaterial = material[1];


            //comp2
            var comp2_3_1 = floor3.GetChild(26).GetChild(0).GetComponent<Renderer>();
            comp2_3_1.enabled = true;
            comp2_3_1.sharedMaterial = material[2];

            var comp2_2_1 = floor2.GetChild(3).GetChild(0).GetComponent<Renderer>();
            comp2_2_1.enabled = true;
            comp2_2_1.sharedMaterial = material[2];

            var comp2_2_2 = floor2.GetChild(4).GetChild(0).GetComponent<Renderer>();
            comp2_2_2.enabled = true;
            comp2_2_2.sharedMaterial = material[2];

            var comp2_1_1 = floor1.GetChild(3).GetChild(0).GetComponent<Renderer>();
            comp2_1_1.enabled = true;
            comp2_1_1.sharedMaterial = material[2];

            var comp2_1_2 = floor1.GetChild(4).GetChild(0).GetComponent<Renderer>();
            comp2_1_2.enabled = true;
            comp2_1_2.sharedMaterial = material[2];

            var comp2_0_1 = floor0.GetChild(3).GetChild(0).GetComponent<Renderer>();
            comp2_0_1.enabled = true;
            comp2_0_1.sharedMaterial = material[2];

            var comp2_0_2 = floor0.GetChild(4).GetChild(0).GetComponent<Renderer>();
            comp2_0_2.enabled = true;
            comp2_0_2.sharedMaterial = material[2];

            //comp3
            var comp3_3_1 = floor3.GetChild(19).GetChild(0).GetComponent<Renderer>();
            comp3_3_1.enabled = true;
            comp3_3_1.sharedMaterial = material[3];

            var comp3_2_1 = floor2.GetChild(7).GetChild(0).GetComponent<Renderer>();
            comp3_2_1.enabled = true;
            comp3_2_1.sharedMaterial = material[3];

            var comp3_2_2 = floor2.GetChild(9).GetChild(0).GetComponent<Renderer>();
            comp3_2_2.enabled = true;
            comp3_2_2.sharedMaterial = material[3];

            var comp3_1_1 = floor1.GetChild(7).GetChild(0).GetComponent<Renderer>();
            comp3_1_1.enabled = true;
            comp3_1_1.sharedMaterial = material[3];

            var comp3_1_2 = floor1.GetChild(9).GetChild(0).GetComponent<Renderer>();
            comp3_1_2.enabled = true;
            comp3_1_2.sharedMaterial = material[3];

            var comp3_0_1 = floor0.GetChild(7).GetChild(0).GetComponent<Renderer>();
            comp3_0_1.enabled = true;
            comp3_0_1.sharedMaterial = material[3];

            var comp3_0_2 = floor0.GetChild(9).GetChild(0).GetComponent<Renderer>();
            comp3_0_2.enabled = true;
            comp3_0_2.sharedMaterial = material[3];
        }
        else
        {
            // comp1
            var comp1_3_1 = floor3.GetChild(5).GetChild(0).GetComponent<Renderer>();
            comp1_3_1.enabled = true;
            comp1_3_1.sharedMaterial = material[0];

            var comp1_3_2 = floor3.GetChild(6).GetChild(0).GetComponent<Renderer>();
            comp1_3_2.enabled = true;
            comp1_3_2.sharedMaterial = material[0];

            var comp1_2_1 = floor2.GetChild(14).GetChild(0).GetComponent<Renderer>();
            comp1_2_1.enabled = true;
            comp1_2_1.sharedMaterial = material[0];

            var comp1_2_2 = floor2.GetChild(13).GetChild(0).GetComponent<Renderer>();
            comp1_2_2.enabled = true;
            comp1_2_2.sharedMaterial = material[0];

            var comp1_2_3 = floor2.GetChild(11).GetChild(0).GetComponent<Renderer>();
            comp1_2_3.enabled = true;
            comp1_2_3.sharedMaterial = material[0];

            var comp1_1_1 = floor1.GetChild(14).GetChild(0).GetComponent<Renderer>();
            comp1_1_1.enabled = true;
            comp1_1_1.sharedMaterial = material[0];

            var comp1_1_2 = floor1.GetChild(13).GetChild(0).GetComponent<Renderer>();
            comp1_1_2.enabled = true;
            comp1_1_2.sharedMaterial = material[0];

            var comp1_1_3 = floor1.GetChild(11).GetChild(0).GetComponent<Renderer>();
            comp1_1_3.enabled = true;
            comp1_1_3.sharedMaterial = material[0];

            var comp1_0_1 = floor0.GetChild(14).GetChild(0).GetComponent<Renderer>();
            comp1_0_1.enabled = true;
            comp1_0_1.sharedMaterial = material[0];

            var comp1_0_2 = floor0.GetChild(13).GetChild(0).GetComponent<Renderer>();
            comp1_0_2.enabled = true;
            comp1_0_2.sharedMaterial = material[0];

            var comp1_0_3 = floor0.GetChild(11).GetChild(0).GetComponent<Renderer>();
            comp1_0_3.enabled = true;
            comp1_0_3.sharedMaterial = material[0];



            //comp2
            var comp2_3_1 = floor3.GetChild(26).GetChild(0).GetComponent<Renderer>();
            comp2_3_1.enabled = true;
            comp2_3_1.sharedMaterial = material[0];

            var comp2_2_1 = floor2.GetChild(3).GetChild(0).GetComponent<Renderer>();
            comp2_2_1.enabled = true;
            comp2_2_1.sharedMaterial = material[0];

            var comp2_2_2 = floor2.GetChild(4).GetChild(0).GetComponent<Renderer>();
            comp2_2_2.enabled = true;
            comp2_2_2.sharedMaterial = material[0];

            var comp2_1_1 = floor1.GetChild(3).GetChild(0).GetComponent<Renderer>();
            comp2_1_1.enabled = true;
            comp2_1_1.sharedMaterial = material[0];

            var comp2_1_2 = floor1.GetChild(4).GetChild(0).GetComponent<Renderer>();
            comp2_1_2.enabled = true;
            comp2_1_2.sharedMaterial = material[0];

            var comp2_0_1 = floor0.GetChild(3).GetChild(0).GetComponent<Renderer>();
            comp2_0_1.enabled = true;
            comp2_0_1.sharedMaterial = material[0];

            var comp2_0_2 = floor0.GetChild(4).GetChild(0).GetComponent<Renderer>();
            comp2_0_2.enabled = true;
            comp2_0_2.sharedMaterial = material[0];

            //comp3
            var comp3_3_1 = floor3.GetChild(19).GetChild(0).GetComponent<Renderer>();
            comp3_3_1.enabled = true;
            comp3_3_1.sharedMaterial = material[0];

            var comp3_2_1 = floor2.GetChild(7).GetChild(0).GetComponent<Renderer>();
            comp3_2_1.enabled = true;
            comp3_2_1.sharedMaterial = material[0];

            var comp3_2_2 = floor2.GetChild(9).GetChild(0).GetComponent<Renderer>();
            comp3_2_2.enabled = true;
            comp3_2_2.sharedMaterial = material[0];

            var comp3_1_1 = floor1.GetChild(7).GetChild(0).GetComponent<Renderer>();
            comp3_1_1.enabled = true;
            comp3_1_1.sharedMaterial = material[0];

            var comp3_1_2 = floor1.GetChild(9).GetChild(0).GetComponent<Renderer>();
            comp3_1_2.enabled = true;
            comp3_1_2.sharedMaterial = material[0];

            var comp3_0_1 = floor0.GetChild(7).GetChild(0).GetComponent<Renderer>();
            comp3_0_1.enabled = true;
            comp3_0_1.sharedMaterial = material[0];

            var comp3_0_2 = floor0.GetChild(9).GetChild(0).GetComponent<Renderer>();
            comp3_0_2.enabled = true;
            comp3_0_2.sharedMaterial = material[0];
        }
        active = !active;
      
    }
    }
