﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShowLogin : MonoBehaviour
{
    public GameObject loginscreen;
    public GameObject Panel;
    // Start is called before the first frame update
    public void Display()
    {
        Panel.SetActive(false);
        loginscreen.SetActive(true);
    }
}
