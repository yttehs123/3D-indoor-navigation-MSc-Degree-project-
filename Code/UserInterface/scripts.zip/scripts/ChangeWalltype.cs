﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeWalltype : MonoBehaviour
{
    public GameObject WallTypeButton;

    private string type = "full";

    public Sprite fullImg;
    public Sprite halfImg;
    public Sprite flatImg;
    public Sprite wiresImg;

    public Text txt;

    public GameObject floor_0;
    public GameObject floor_1;
    public GameObject floor_2;
    public GameObject floor_3;

    public Material[] materials;
    Renderer rend;

    public void ChangeIcon()
    {
        var totext = txt.text.ToString();
        var cnt = Int32.Parse(totext);
        if (type == "full")
        {
            WallTypeButton.GetComponent<Image>().sprite = halfImg;
            type = "half";
        }
        else if (type == "half")
        {
            WallTypeButton.GetComponent<Image>().sprite = flatImg;
            type = "flat";
            if(cnt == 0) {
                floor_0.transform.localScale = new Vector3(15, 1, 15);
                floor_0.transform.position -= new Vector3(0, 5248, 0);

                floor_1.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_1.transform.position += new Vector3(0, 9544, 0);

                floor_2.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_2.transform.position += new Vector3(0, 9544, 0);

                floor_3.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_3.transform.position += new Vector3(0, 9544, 0);
            }
            else if (cnt == 1)
            {
                floor_1.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_1.transform.position += new Vector3(0, 9544, 0);

                floor_2.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_2.transform.position += new Vector3(0, 9544, 0);

                floor_3.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_3.transform.position += new Vector3(0, 9544, 0);
            }
            else if (cnt == 2)
            {
                floor_2.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_2.transform.position += new Vector3(0, 9544, 0);

                floor_3.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_3.transform.position += new Vector3(0, 9544, 0);
            }
            else if (cnt == 3)
            {
                floor_3.transform.localScale = new Vector3((float)4.5387, 1, (float)4.5);
                floor_3.transform.position += new Vector3(0, 9544, 0);
            }

        }
        else if (type == "flat")
        {
            WallTypeButton.GetComponent<Image>().sprite = wiresImg;
            type = "wires";

            floor_0.transform.localScale    = new Vector3(15, 15, 15);
            floor_0.transform.localPosition = new Vector3(-5008, 5248, -2623);

            floor_1.transform.localScale    = new Vector3((float)4.5387, (float)4.5, (float)4.5);
            floor_1.transform.localPosition = new Vector3((float)8990.3, -11934, 12500);

            floor_2.transform.localScale    = new Vector3((float)4.5387, (float)4.5, (float)4.5);
            floor_2.transform.localPosition = new Vector3((float)8990.3, -11768, 12500);

            floor_3.transform.localScale    = new Vector3((float)4.5387, (float)4.5, (float)4.5);
            floor_3.transform.localPosition = new Vector3((float)8990.3, -11607, 12500);

            Wireframe(materials[1]);
        }
        else
        {
            WallTypeButton.GetComponent<Image>().sprite = fullImg;
            type = "full";


            Wireframe(materials[0]);

        }

 
    }

    public void Wireframe(Material mat)
    {
        foreach (Transform child in floor_0.transform)
        {
            var obj = child.GetChild(0).GetComponent<Renderer>();
            obj.enabled = true;
            obj.sharedMaterial = mat;
        }

        var first = true;
        foreach (Transform child in floor_1.transform)
        {
            if (first)
            {
                var obj2 = child.GetComponent<Renderer>();
                obj2.enabled = true;
                obj2.sharedMaterial = mat;

                first = false;
            }
            else
            {
                var obj = child.GetChild(0).GetComponent<Renderer>();
                obj.enabled = true;
                obj.sharedMaterial = mat;

            }
        }

        var first2 = true;
        foreach (Transform child in floor_2.transform)
        {
            if (first2)
            {
                var obj2 = child.GetComponent<Renderer>();
                obj2.enabled = true;
                obj2.sharedMaterial = mat;

                first2 = false;
            }
            else
            {
                var obj = child.GetChild(0).GetComponent<Renderer>();
                obj.enabled = true;
                obj.sharedMaterial = mat;

            }
        }


        var first3 = true;

        foreach (Transform child in floor_3.transform)
        {
            if (first3)
            {
                var obj2 = child.GetComponent<Renderer>();
                obj2.enabled = true;
                obj2.sharedMaterial = mat;

                first3 = false;
            }
            else
            {
                var obj = child.GetChild(0).GetComponent<Renderer>();
                obj.enabled = true;
                obj.sharedMaterial = mat;

            }
        }
    }
}
