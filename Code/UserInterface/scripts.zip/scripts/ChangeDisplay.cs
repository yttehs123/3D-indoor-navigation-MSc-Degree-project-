﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChangeDisplay : MonoBehaviour
{
    public GameObject DisplayTypeButton;

    private string type = "3D";

    public Sprite twoDImg;
    public Sprite threeDImg;
    public Sprite arImg;

    public GameObject camera3d;
    public GameObject camera2d;

    public GameObject floors;


    public void ChangeIcon()
    {
        if (type == "3D")
        {
            DisplayTypeButton.GetComponent<Image>().sprite = twoDImg;
            camera2d.SetActive(true);
            camera3d.SetActive(false);
            type = "2D";
        }
        else if (type == "2D") {
            DisplayTypeButton.GetComponent<Image>().sprite = arImg;
            type = "AR";
        }
        else
        {
            DisplayTypeButton.GetComponent<Image>().sprite = threeDImg;
            camera2d.SetActive(false);
            camera3d.SetActive(true);
            type = "3D";
        }
    }
}
