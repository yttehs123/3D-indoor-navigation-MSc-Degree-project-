﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FadeMenu : MonoBehaviour
{
    private bool mFaded = true;

    public float Duration = 0.4f;

    public GameObject MenuButton;

    public GameObject Canvasgroup;

    public void Fade()
    {
        RectTransform rt = MenuButton.GetComponent<RectTransform>();
        if (mFaded)
        {
            rt.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Right, 250, rt.rect.width);
            Canvasgroup.SetActive(true);
        }
        else
        {
            rt.SetInsetAndSizeFromParentEdge(RectTransform.Edge.Right, 10, rt.rect.width);
            Canvasgroup.SetActive(false);
        }
        mFaded = !mFaded;
    }

    public void routepanel()
    {
        if (mFaded)
        {
            Canvasgroup.SetActive(true);
        }
        else
        {
            Canvasgroup.SetActive(false);
        }
        mFaded = !mFaded;
    }



    public IEnumerator DoFade(CanvasGroup canvGroup, float start, float end)
    {
        float counter = 0f;

        while(counter < Duration)
        {
            counter += Time.deltaTime;
            canvGroup.alpha = Mathf.Lerp(start, end, counter / Duration);
            yield return null;
        }
    }
}
